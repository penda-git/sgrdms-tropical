# SGRDMS – Système de Gestion des Rendez-vous et Dossiers Médicaux
## Centre de Santé Le Tropical

---

## 🚀 Déploiement sur Render (Instructions)

### Étape 1 – Préparer le dépôt GitHub
1. Créez un dépôt GitHub (ex: `sgrdms-tropical`)
2. Copiez tous les fichiers dans ce dépôt
3. Faites un `git push`

### Étape 2 – Déployer sur Render
1. Allez sur **https://render.com** → "New +" → **Web Service**
2. Connectez votre dépôt GitHub
3. Configurez :
   - **Name**: `sgrdms-tropical`
   - **Environment**: Python
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn app:app --bind 0.0.0.0:$PORT`
4. Ajoutez la variable d'environnement :
   - `SECRET_KEY` → une chaîne aléatoire longue (ex: `tropical-secret-2024-xyz`)

### Étape 3 – Base de données (optionnel pour production)
- Sur Render, créez un **PostgreSQL** database
- Copiez la **connection string** dans la variable `DATABASE_URL`
- Le code supporte automatiquement PostgreSQL et SQLite

### Étape 4 – Lancer
- Cliquez "Deploy" → l'app sera disponible sur `https://sgrdms-tropical.onrender.com`

---

## 🗂️ Structure du projet

```
sgrdms/
├── app.py                  # Application Flask principale + modèles + routes
├── requirements.txt        # Dépendances Python
├── render.yaml             # Config Render (optionnel)
├── static/
│   ├── css/main.css        # Styles (vert/blanc/bleu)
│   └── js/main.js          # JS: sidebar, notifications sonores, polling
└── templates/
    ├── base.html           # Template de base avec sidebar responsive
    ├── login.html          # Page de connexion
    ├── dashboard.html      # Tableau de bord (adapté par rôle)
    ├── patients.html       # Liste patients
    ├── nouveau_patient.html
    ├── detail_patient.html # Dossier médical complet
    ├── rendez_vous.html
    ├── nouveau_rdv.html
    ├── consultations.html
    ├── nouvelle_consultation.html
    ├── urgences.html
    ├── pharmacie.html
    ├── facturation.html
    ├── medecins.html
    ├── nouveau_medecin.html
    ├── services.html
    ├── admin_utilisateurs.html
    └── nouvel_utilisateur.html
```

---

## 👥 Comptes de démonstration

| Rôle          | Utilisateur      | Mot de passe  |
|---------------|------------------|---------------|
| Admin         | `admin`          | `admin123`    |
| Médecin       | `dr_diallo`      | `medecin123`  |
| Réceptionniste| `receptionniste` | `recep123`    |
| Pharmacien    | `pharmacien`     | `pharma123`   |

---

## 🔒 Sécurité par rôle

| Fonctionnalité        | Admin | Médecin | Récept. | Pharmacien |
|-----------------------|-------|---------|---------|------------|
| Tableau de bord       | ✅    | ✅      | ✅      | ✅         |
| Patients              | ✅    | Ses patients | ✅ | ❌        |
| Rendez-vous           | ✅    | Ses RDV | ✅     | ❌         |
| Consultations         | ✅    | Ses consult. | ❌ | ❌       |
| Urgences              | ✅    | Son service | ✅  | ❌        |
| Pharmacie             | ✅    | Lecture | ❌      | ✅         |
| Facturation           | ✅    | ❌      | ✅      | ❌         |
| Gestion médecins      | ✅    | ❌      | Lecture | ❌         |
| Utilisateurs          | ✅    | ❌      | ❌      | ❌         |

---

## 🔔 Notifications sonores
- Polling automatique toutes les 30 secondes
- Son différent selon le type : info (Do-Mi) / urgence (alarme)
- Toast visuel + badge sur la cloche
- Badge rouge animé sur "Urgences" dans la sidebar

## 📱 Responsive
- Desktop : sidebar fixe 260px
- Tablette/Mobile : sidebar en drawer (toggle hamburger)
- Tableaux : colonnes masquées sur mobile pour lisibilité
