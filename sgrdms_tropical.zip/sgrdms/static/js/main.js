// ============================================
// SGRDMS – Main JavaScript
// ============================================

// ──── Sidebar toggle (mobile) ────
const sidebar   = document.getElementById('sidebar');
const menuToggle = document.getElementById('menuToggle');
const sidebarClose = document.getElementById('sidebarClose');
const overlay   = document.getElementById('overlay');

function openSidebar() {
  sidebar?.classList.add('open');
  overlay?.classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeSidebar() {
  sidebar?.classList.remove('open');
  overlay?.classList.remove('open');
  document.body.style.overflow = '';
}

menuToggle?.addEventListener('click', openSidebar);
sidebarClose?.addEventListener('click', closeSidebar);
overlay?.addEventListener('click', closeSidebar);

// ──── Notification bell ────
const notifBtn      = document.getElementById('notifBtn');
const notifDropdown = document.getElementById('notifDropdown');

notifBtn?.addEventListener('click', (e) => {
  e.stopPropagation();
  notifDropdown?.classList.toggle('open');
});

document.addEventListener('click', () => {
  notifDropdown?.classList.remove('open');
});

notifDropdown?.addEventListener('click', e => e.stopPropagation());

// ──── Sound engine ────
let audioCtx = null;

function getAudioCtx() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }
  return audioCtx;
}

function playNotifSound(type = 'info') {
  try {
    const ctx = getAudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    const freqs = {
      info:    [523, 659],   // Do Mi
      urgence: [880, 440, 880], // Urgent alarm
      alerte:  [659, 523],   // Mi Do (descending)
    };

    const notes = freqs[type] || freqs.info;
    const now = ctx.currentTime;
    const dur = 0.15;

    notes.forEach((freq, i) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.connect(g); g.connect(ctx.destination);
      o.frequency.value = freq;
      o.type = type === 'urgence' ? 'square' : 'sine';
      g.gain.setValueAtTime(0, now + i * dur);
      g.gain.linearRampToValueAtTime(0.25, now + i * dur + 0.02);
      g.gain.linearRampToValueAtTime(0, now + i * dur + dur - 0.01);
      o.start(now + i * dur);
      o.stop(now + i * dur + dur);
    });
  } catch(e) {
    console.warn('Audio non disponible:', e);
  }
}

// ──── Notification polling ────
let lastNotifIds = new Set();
let lastUrgenceCount = 0;

function renderNotifications(notifs) {
  const list = document.getElementById('notifList');
  const countEl = document.getElementById('notifCount');
  if (!list) return;

  if (!notifs.length) {
    list.innerHTML = '<p class="notif-empty"><i class="fas fa-bell-slash"></i> Aucune notification</p>';
    if (countEl) countEl.style.display = 'none';
    return;
  }

  if (countEl) {
    countEl.textContent = notifs.length;
    countEl.style.display = 'flex';
  }

  list.innerHTML = notifs.map(n => `
    <div class="notif-item unread" onclick="markRead(${n.id}, this)">
      <div class="notif-objet">
        <i class="fas fa-${iconForType(n.type)}" style="color: ${colorForType(n.type)}; margin-right:5px;"></i>
        ${escHtml(n.objet)}
      </div>
      <div class="notif-contenu">${escHtml(n.contenu)}</div>
      <div class="notif-date"><i class="fas fa-clock"></i> ${n.date}</div>
    </div>
  `).join('');
}

function iconForType(type) {
  const map = { urgence: 'ambulance', rdv: 'calendar', consultation: 'stethoscope',
    nouveau_patient: 'user-plus', facture: 'file-invoice', alerte_stock: 'exclamation-triangle' };
  return map[type] || 'bell';
}

function colorForType(type) {
  const map = { urgence: '#ef4444', rdv: '#3b82f6', consultation: '#059669',
    nouveau_patient: '#8b5cf6', facture: '#f97316', alerte_stock: '#eab308' };
  return map[type] || '#6b7280';
}

function escHtml(str) {
  const d = document.createElement('div');
  d.textContent = str;
  return d.innerHTML;
}

async function markRead(id, el) {
  try {
    await fetch(`/api/notifications/${id}/lu`, { method: 'POST' });
    el.classList.remove('unread');
    el.style.opacity = '.6';
    await fetchNotifications();
  } catch(e) {}
}

async function markAllRead() {
  const items = document.querySelectorAll('.notif-item.unread');
  // no bulk API, just re-fetch after small delay
  items.forEach(item => item.classList.remove('unread'));
  const countEl = document.getElementById('notifCount');
  if (countEl) countEl.style.display = 'none';
}

async function fetchNotifications() {
  try {
    const res = await fetch('/api/notifications');
    const notifs = await res.json();

    // Check for new ones
    const newIds = notifs.filter(n => !lastNotifIds.has(n.id));
    if (newIds.length > 0 && lastNotifIds.size > 0) {
      const hasUrgence = newIds.some(n => n.type === 'urgence');
      playNotifSound(hasUrgence ? 'urgence' : 'info');
      // Show toast for new notif
      if (newIds[0]) showToast(newIds[0]);
    }

    newIds.forEach(n => lastNotifIds.add(n.id));
    renderNotifications(notifs);
  } catch(e) {}
}

async function fetchUrgences() {
  try {
    const res = await fetch('/api/urgences/count');
    const data = await res.json();
    const badge = document.getElementById('urgence-badge');
    if (badge) {
      if (data.count > 0) {
        badge.textContent = data.count;
        badge.style.display = 'inline-flex';
        if (data.count > lastUrgenceCount && lastUrgenceCount >= 0) {
          playNotifSound('urgence');
        }
      } else {
        badge.style.display = 'none';
      }
      lastUrgenceCount = data.count;
    }
  } catch(e) {}
}

// ──── Toast notification ────
function showToast(notif) {
  const toast = document.createElement('div');
  toast.className = 'toast-notif';
  toast.innerHTML = `
    <i class="fas fa-${iconForType(notif.type)}" style="color:${colorForType(notif.type)}"></i>
    <div>
      <strong>${escHtml(notif.objet)}</strong>
      <p>${escHtml(notif.contenu)}</p>
    </div>
    <button onclick="this.parentElement.remove()">×</button>
  `;
  document.body.appendChild(toast);
  setTimeout(() => toast.classList.add('show'), 50);
  setTimeout(() => { toast.classList.remove('show'); setTimeout(() => toast.remove(), 400); }, 5000);
}

// ──── Polling interval ────
if (document.getElementById('notifBtn')) {
  fetchNotifications();
  fetchUrgences();
  setInterval(fetchNotifications, 30000);  // every 30s
  setInterval(fetchUrgences, 15000);       // every 15s
}

// ──── Table search ────
function initTableSearch(inputId, tableId) {
  const input = document.getElementById(inputId);
  const table = document.getElementById(tableId);
  if (!input || !table) return;
  input.addEventListener('input', () => {
    const q = input.value.toLowerCase();
    table.querySelectorAll('tbody tr').forEach(row => {
      row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
  });
}

// ──── Modal helpers ────
function openModal(id) { document.getElementById(id)?.classList.add('open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('open'); }

document.querySelectorAll('[data-modal-open]').forEach(btn => {
  btn.addEventListener('click', () => openModal(btn.dataset.modalOpen));
});
document.querySelectorAll('[data-modal-close]').forEach(btn => {
  btn.addEventListener('click', () => closeModal(btn.dataset.modalClose));
});
document.querySelectorAll('.modal-overlay').forEach(overlay => {
  overlay.addEventListener('click', e => {
    if (e.target === overlay) overlay.classList.remove('open');
  });
});

// ──── Auto-dismiss alerts after 6s ────
document.querySelectorAll('.alert').forEach(alert => {
  setTimeout(() => {
    alert.style.opacity = '0';
    alert.style.transform = 'translateY(-8px)';
    alert.style.transition = 'all .4s';
    setTimeout(() => alert.remove(), 400);
  }, 6000);
});
