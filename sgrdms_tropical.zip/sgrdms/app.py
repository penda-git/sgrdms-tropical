import os
from datetime import datetime, date
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-tropical-2024')

# Database config: use DATABASE_URL from Render, fallback to SQLite locally
database_url = os.environ.get('DATABASE_URL', 'sqlite:///sgrdms.db')
if database_url.startswith('postgres://'):
    database_url = database_url.replace('postgres://', 'postgresql://', 1)
app.config['SQLALCHEMY_DATABASE_URI'] = database_url
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# ─────────────────────────────────────────
# MODELS
# ─────────────────────────────────────────

class Utilisateur(UserMixin, db.Model):
    __tablename__ = 'utilisateur'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(30), nullable=False)  # admin, medecin, receptionniste, pharmacien
    actif = db.Column(db.Boolean, default=True)
    medecin = db.relationship('Medecin', backref='utilisateur', uselist=False)
    receptionniste = db.relationship('Receptionniste', backref='utilisateur', uselist=False)
    pharmacien = db.relationship('Pharmacien', backref='utilisateur', uselist=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Centre(db.Model):
    __tablename__ = 'centre'
    id_centre = db.Column(db.Integer, primary_key=True)
    designation = db.Column(db.String(100), nullable=False)
    adresse = db.Column(db.String(200))
    telephone = db.Column(db.String(20))
    services = db.relationship('Services', backref='centre', lazy=True)

class Services(db.Model):
    __tablename__ = 'services'
    id_services = db.Column(db.Integer, primary_key=True)
    libelle = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    id_centre = db.Column(db.Integer, db.ForeignKey('centre.id_centre'))
    medecins = db.relationship('Medecin', backref='service', lazy=True)

class Medecin(db.Model):
    __tablename__ = 'medecin'
    matricule = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(80), nullable=False)
    prenom = db.Column(db.String(80), nullable=False)
    telephone = db.Column(db.String(20))
    specialite = db.Column(db.String(100))
    email = db.Column(db.String(120))
    id_services = db.Column(db.Integer, db.ForeignKey('services.id_services'))
    utilisateur_id = db.Column(db.Integer, db.ForeignKey('utilisateur.id'))
    creneaux = db.relationship('Creneau', backref='medecin', lazy=True)
    rendez_vous = db.relationship('RendezVous', backref='medecin', lazy=True)
    consultations = db.relationship('Consultation', backref='medecin', lazy=True)

class Receptionniste(db.Model):
    __tablename__ = 'receptionniste'
    id_receptionniste = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(80), nullable=False)
    prenom = db.Column(db.String(80), nullable=False)
    telephone = db.Column(db.String(20))
    email = db.Column(db.String(120))
    utilisateur_id = db.Column(db.Integer, db.ForeignKey('utilisateur.id'))

class Patient(db.Model):
    __tablename__ = 'patient'
    id_patient = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(80), nullable=False)
    prenom = db.Column(db.String(80), nullable=False)
    sexe = db.Column(db.String(10))
    adresse = db.Column(db.String(200))
    telephone = db.Column(db.String(20))
    date_naissance = db.Column(db.Date)
    email = db.Column(db.String(120))
    id_assurance = db.Column(db.Integer, db.ForeignKey('assurance.id_assurance'))
    dossier = db.relationship('Dossier', backref='patient', uselist=False)
    rendez_vous = db.relationship('RendezVous', backref='patient', lazy=True)
    consultations = db.relationship('Consultation', backref='patient', lazy=True)
    notifications = db.relationship('Notification', backref='patient', lazy=True)

class Creneau(db.Model):
    __tablename__ = 'creneau'
    id_creneau = db.Column(db.Integer, primary_key=True)
    jour = db.Column(db.String(20), nullable=False)
    heure_debut = db.Column(db.String(10), nullable=False)
    heure_fin = db.Column(db.String(10), nullable=False)
    type_consultation = db.Column(db.String(30))
    statut = db.Column(db.String(20), default='disponible')
    matricule = db.Column(db.Integer, db.ForeignKey('medecin.matricule'))
    rendez_vous = db.relationship('RendezVous', backref='creneau', lazy=True)

class RendezVous(db.Model):
    __tablename__ = 'rendez_vous'
    id_rendez_vous = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.DateTime, nullable=False)
    type = db.Column(db.String(30))
    statut = db.Column(db.String(20), default='planifié')
    id_creneau = db.Column(db.Integer, db.ForeignKey('creneau.id_creneau'))
    matricule = db.Column(db.Integer, db.ForeignKey('medecin.matricule'))
    id_patient = db.Column(db.Integer, db.ForeignKey('patient.id_patient'))

class Consultation(db.Model):
    __tablename__ = 'consultation'
    id_consultation = db.Column(db.Integer, primary_key=True)
    date_consultation = db.Column(db.DateTime, default=datetime.utcnow)
    observation = db.Column(db.Text)
    diagnostic = db.Column(db.Text)
    type = db.Column(db.String(30))
    id_patient = db.Column(db.Integer, db.ForeignKey('patient.id_patient'))
    matricule = db.Column(db.Integer, db.ForeignKey('medecin.matricule'))
    facture = db.relationship('Facture', backref='consultation', uselist=False)
    ordonnances = db.relationship('Ordonnance', backref='consultation', lazy=True)

class Dossier(db.Model):
    __tablename__ = 'dossier'
    num_dossier = db.Column(db.Integer, primary_key=True)
    date_creation = db.Column(db.DateTime, default=datetime.utcnow)
    diagnostic = db.Column(db.Text)
    id_patient = db.Column(db.Integer, db.ForeignKey('patient.id_patient'))

class Assurance(db.Model):
    __tablename__ = 'assurance'
    id_assurance = db.Column(db.Integer, primary_key=True)
    nom_assurance = db.Column(db.String(100), nullable=False)
    adresse_assurance = db.Column(db.String(200))
    contrat = db.Column(db.String(100))
    patients = db.relationship('Patient', backref='assurance', lazy=True)

class Facture(db.Model):
    __tablename__ = 'facture'
    num_facture = db.Column(db.Integer, primary_key=True)
    montant = db.Column(db.Float, nullable=False)
    date = db.Column(db.DateTime, default=datetime.utcnow)
    statut = db.Column(db.String(20), default='impayée')
    id_consultation = db.Column(db.Integer, db.ForeignKey('consultation.id_consultation'))
    id_assurance = db.Column(db.Integer, db.ForeignKey('assurance.id_assurance'))
    paiements = db.relationship('Paiement', backref='facture', lazy=True)

class Paiement(db.Model):
    __tablename__ = 'paiement'
    id_paiement = db.Column(db.Integer, primary_key=True)
    date_paiement = db.Column(db.DateTime, default=datetime.utcnow)
    montant = db.Column(db.Float)
    mode_paiement = db.Column(db.String(30))
    statut = db.Column(db.String(20))
    num_facture = db.Column(db.Integer, db.ForeignKey('facture.num_facture'))
    id_patient = db.Column(db.Integer, db.ForeignKey('patient.id_patient'))

class Medicament(db.Model):
    __tablename__ = 'medicament'
    id_medicament = db.Column(db.Integer, primary_key=True)
    libelle = db.Column(db.String(150), nullable=False)
    prix = db.Column(db.Float)
    dosage = db.Column(db.String(100))
    contre_indication = db.Column(db.Text)
    notice = db.Column(db.Text)
    type = db.Column(db.String(50))
    id_stock = db.Column(db.Integer, db.ForeignKey('stock.id_stock'))

class Stock(db.Model):
    __tablename__ = 'stock'
    id_stock = db.Column(db.Integer, primary_key=True)
    quantite = db.Column(db.Integer, default=0)
    date_stock = db.Column(db.DateTime, default=datetime.utcnow)
    statut = db.Column(db.String(20), default='normal')
    medicaments = db.relationship('Medicament', backref='stock', lazy=True)
    alertes = db.relationship('AlerteStock', backref='stock', lazy=True)

class AlerteStock(db.Model):
    __tablename__ = 'alerte_stock'
    id_alerte = db.Column(db.Integer, primary_key=True)
    type_alerte = db.Column(db.String(50))
    date = db.Column(db.DateTime, default=datetime.utcnow)
    message = db.Column(db.Text)
    quantite_actuel = db.Column(db.Integer)
    statut = db.Column(db.String(20), default='active')
    id_stock = db.Column(db.Integer, db.ForeignKey('stock.id_stock'))
    id_medicament = db.Column(db.Integer, db.ForeignKey('medicament.id_medicament'))

class Pharmacien(db.Model):
    __tablename__ = 'pharmacien'
    id_pharmacien = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(80), nullable=False)
    prenom = db.Column(db.String(80), nullable=False)
    telephone = db.Column(db.String(20))
    email = db.Column(db.String(120))
    id_stock = db.Column(db.Integer, db.ForeignKey('stock.id_stock'))
    utilisateur_id = db.Column(db.Integer, db.ForeignKey('utilisateur.id'))

class Ordonnance(db.Model):
    __tablename__ = 'ordonnance'
    id_ordonnance = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.DateTime, default=datetime.utcnow)
    duree = db.Column(db.String(50))
    id_consultation = db.Column(db.Integer, db.ForeignKey('consultation.id_consultation'))
    matricule = db.Column(db.Integer, db.ForeignKey('medecin.matricule'))
    lignes = db.relationship('LigneOrdonnance', backref='ordonnance', lazy=True)

class LigneOrdonnance(db.Model):
    __tablename__ = 'ligne_ordonnance'
    id = db.Column(db.Integer, primary_key=True)
    id_ordonnance = db.Column(db.Integer, db.ForeignKey('ordonnance.id_ordonnance'))
    id_medicament = db.Column(db.Integer, db.ForeignKey('medicament.id_medicament'))
    posologie = db.Column(db.String(200))
    medicament = db.relationship('Medicament')

class Notification(db.Model):
    __tablename__ = 'notification'
    id_notification = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.String(50))
    contenu = db.Column(db.Text)
    date_envoie = db.Column(db.DateTime, default=datetime.utcnow)
    statut = db.Column(db.String(20), default='non_lu')
    objet = db.Column(db.String(200))
    id_patient = db.Column(db.Integer, db.ForeignKey('patient.id_patient'))
    matricule = db.Column(db.Integer, db.ForeignKey('medecin.matricule'))
    id_receptionniste = db.Column(db.Integer, db.ForeignKey('receptionniste.id_receptionniste'))

class Urgence(db.Model):
    __tablename__ = 'urgence'
    id_urgence = db.Column(db.Integer, primary_key=True)
    date_arrivee = db.Column(db.DateTime, default=datetime.utcnow)
    niveau = db.Column(db.String(20))  # critique, urgent, normal
    statut = db.Column(db.String(20), default='en_attente')
    id_patient = db.Column(db.Integer, db.ForeignKey('patient.id_patient'))
    id_services = db.Column(db.Integer, db.ForeignKey('services.id_services'))

class Teleconsultation(db.Model):
    __tablename__ = 'teleconsultation'
    id_teleconsultation = db.Column(db.Integer, primary_key=True)
    statut = db.Column(db.String(20), default='planifiée')
    date_debut = db.Column(db.DateTime)
    id_patient = db.Column(db.Integer, db.ForeignKey('patient.id_patient'))
    matricule = db.Column(db.Integer, db.ForeignKey('medecin.matricule'))

# ─────────────────────────────────────────
# LOGIN MANAGER
# ─────────────────────────────────────────

@login_manager.user_loader
def load_user(user_id):
    return Utilisateur.query.get(int(user_id))

def role_required(*roles):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated or current_user.role not in roles:
                flash('Accès non autorisé.', 'danger')
                return redirect(url_for('dashboard'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# ─────────────────────────────────────────
# AUTH ROUTES
# ─────────────────────────────────────────

@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = Utilisateur.query.filter_by(username=username).first()
        if user and user.check_password(password) and user.actif:
            login_user(user)
            return redirect(url_for('dashboard'))
        flash('Identifiants incorrects.', 'danger')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# ─────────────────────────────────────────
# DASHBOARD
# ─────────────────────────────────────────

@app.route('/dashboard')
@login_required
def dashboard():
    stats = {}
    notifications = []
    urgences = []

    if current_user.role == 'admin':
        stats['patients'] = Patient.query.count()
        stats['medecins'] = Medecin.query.count()
        stats['rdv_aujourd_hui'] = RendezVous.query.filter(
            db.func.date(RendezVous.date) == date.today()
        ).count()
        stats['factures_impayees'] = Facture.query.filter_by(statut='impayée').count()
        urgences = Urgence.query.filter_by(statut='en_attente').order_by(Urgence.date_arrivee.desc()).limit(5).all()
        notifications = Notification.query.filter_by(statut='non_lu').order_by(Notification.date_envoie.desc()).limit(10).all()

    elif current_user.role == 'medecin':
        med = current_user.medecin
        if med:
            stats['mes_rdv'] = RendezVous.query.filter_by(matricule=med.matricule).filter(
                db.func.date(RendezVous.date) == date.today()
            ).count()
            stats['mes_consultations'] = Consultation.query.filter_by(matricule=med.matricule).count()
            stats['mes_patients'] = db.session.query(Patient).join(Consultation).filter(
                Consultation.matricule == med.matricule
            ).distinct().count()
            notifications = Notification.query.filter_by(matricule=med.matricule, statut='non_lu').order_by(
                Notification.date_envoie.desc()).limit(10).all()

    elif current_user.role == 'receptionniste':
        stats['patients'] = Patient.query.count()
        stats['rdv_aujourd_hui'] = RendezVous.query.filter(
            db.func.date(RendezVous.date) == date.today()
        ).count()
        stats['urgences'] = Urgence.query.filter_by(statut='en_attente').count()
        urgences = Urgence.query.filter_by(statut='en_attente').order_by(Urgence.date_arrivee.desc()).limit(5).all()
        notifications = Notification.query.filter_by(statut='non_lu').order_by(Notification.date_envoie.desc()).limit(10).all()

    elif current_user.role == 'pharmacien':
        stats['medicaments'] = Medicament.query.count()
        stats['alertes_stock'] = AlerteStock.query.filter_by(statut='active').count()
        stats['stock_faible'] = Stock.query.filter_by(statut='faible').count()
        alertes = AlerteStock.query.filter_by(statut='active').order_by(AlerteStock.date.desc()).limit(5).all()
        return render_template('dashboard.html', stats=stats, alertes=alertes, notifications=notifications)

    return render_template('dashboard.html', stats=stats, notifications=notifications, urgences=urgences)

# ─────────────────────────────────────────
# PATIENTS
# ─────────────────────────────────────────

@app.route('/patients')
@login_required
@role_required('admin', 'receptionniste', 'medecin')
def patients():
    if current_user.role == 'medecin':
        med = current_user.medecin
        patients = db.session.query(Patient).join(Consultation).filter(
            Consultation.matricule == med.matricule
        ).distinct().all()
    else:
        patients = Patient.query.all()
    return render_template('patients.html', patients=patients)

@app.route('/patients/nouveau', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'receptionniste')
def nouveau_patient():
    assurances = Assurance.query.all()
    if request.method == 'POST':
        try:
            dob = datetime.strptime(request.form['date_naissance'], '%Y-%m-%d').date() if request.form.get('date_naissance') else None
            patient = Patient(
                nom=request.form['nom'], prenom=request.form['prenom'],
                sexe=request.form.get('sexe'), adresse=request.form.get('adresse'),
                telephone=request.form.get('telephone'), date_naissance=dob,
                email=request.form.get('email'),
                id_assurance=request.form.get('id_assurance') or None
            )
            db.session.add(patient)
            db.session.flush()
            dossier = Dossier(id_patient=patient.id_patient)
            db.session.add(dossier)
            notif = Notification(
                type='nouveau_patient', objet='Nouveau patient enregistré',
                contenu=f'Le patient {patient.prenom} {patient.nom} a été enregistré.',
                id_patient=patient.id_patient
            )
            db.session.add(notif)
            db.session.commit()
            flash(f'Patient {patient.prenom} {patient.nom} enregistré avec succès.', 'success')
            return redirect(url_for('patients'))
        except Exception as e:
            db.session.rollback()
            flash(f'Erreur: {str(e)}', 'danger')
    return render_template('nouveau_patient.html', assurances=assurances)

@app.route('/patients/<int:id>')
@login_required
@role_required('admin', 'receptionniste', 'medecin')
def detail_patient(id):
    patient = Patient.query.get_or_404(id)
    if current_user.role == 'medecin':
        med = current_user.medecin
        allowed = Consultation.query.filter_by(id_patient=id, matricule=med.matricule).first()
        if not allowed:
            flash('Accès non autorisé à ce patient.', 'danger')
            return redirect(url_for('patients'))
    consultations = Consultation.query.filter_by(id_patient=id).order_by(Consultation.date_consultation.desc()).all()
    rdvs = RendezVous.query.filter_by(id_patient=id).order_by(RendezVous.date.desc()).all()
    return render_template('detail_patient.html', patient=patient, consultations=consultations, rdvs=rdvs)

# ─────────────────────────────────────────
# RENDEZ-VOUS
# ─────────────────────────────────────────

@app.route('/rendez-vous')
@login_required
def rendez_vous():
    if current_user.role == 'medecin':
        med = current_user.medecin
        rdvs = RendezVous.query.filter_by(matricule=med.matricule).order_by(RendezVous.date.desc()).all()
    elif current_user.role == 'admin' or current_user.role == 'receptionniste':
        rdvs = RendezVous.query.order_by(RendezVous.date.desc()).all()
    else:
        rdvs = []
    return render_template('rendez_vous.html', rdvs=rdvs)

@app.route('/rendez-vous/nouveau', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'receptionniste')
def nouveau_rdv():
    patients = Patient.query.all()
    medecins = Medecin.query.all()
    if request.method == 'POST':
        try:
            rdv = RendezVous(
                date=datetime.strptime(request.form['date'], '%Y-%m-%dT%H:%M'),
                type=request.form.get('type', 'présentiel'),
                statut='planifié',
                matricule=request.form.get('matricule'),
                id_patient=request.form.get('id_patient')
            )
            db.session.add(rdv)
            db.session.flush()
            patient = Patient.query.get(rdv.id_patient)
            notif = Notification(
                type='rdv', objet='Rendez-vous planifié',
                contenu=f'Votre rendez-vous est prévu le {rdv.date.strftime("%d/%m/%Y à %H:%M")}.',
                id_patient=rdv.id_patient, matricule=rdv.matricule
            )
            db.session.add(notif)
            db.session.commit()
            flash('Rendez-vous créé avec succès.', 'success')
            return redirect(url_for('rendez_vous'))
        except Exception as e:
            db.session.rollback()
            flash(f'Erreur: {str(e)}', 'danger')
    return render_template('nouveau_rdv.html', patients=patients, medecins=medecins)

# ─────────────────────────────────────────
# CONSULTATIONS
# ─────────────────────────────────────────

@app.route('/consultations')
@login_required
@role_required('admin', 'medecin', 'receptionniste')
def consultations():
    if current_user.role == 'medecin':
        med = current_user.medecin
        consults = Consultation.query.filter_by(matricule=med.matricule).order_by(Consultation.date_consultation.desc()).all()
    else:
        consults = Consultation.query.order_by(Consultation.date_consultation.desc()).all()
    return render_template('consultations.html', consultations=consults)

@app.route('/consultations/nouvelle', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'medecin')
def nouvelle_consultation():
    if current_user.role == 'medecin':
        med = current_user.medecin
        patients = db.session.query(Patient).join(RendezVous).filter(
            RendezVous.matricule == med.matricule, RendezVous.statut == 'planifié'
        ).distinct().all()
        medecins = [med]
    else:
        patients = Patient.query.all()
        medecins = Medecin.query.all()
    medicaments = Medicament.query.all()
    if request.method == 'POST':
        try:
            mat = request.form.get('matricule') or (current_user.medecin.matricule if current_user.role == 'medecin' else None)
            consult = Consultation(
                observation=request.form.get('observation'),
                diagnostic=request.form.get('diagnostic'),
                type=request.form.get('type', 'standard'),
                id_patient=request.form['id_patient'],
                matricule=mat
            )
            db.session.add(consult)
            db.session.flush()
            # Facture auto
            facture = Facture(montant=float(request.form.get('montant', 5000)), id_consultation=consult.id_consultation)
            db.session.add(facture)
            # Notification
            notif = Notification(
                type='consultation', objet='Consultation effectuée',
                contenu=f'Consultation du {datetime.now().strftime("%d/%m/%Y")} enregistrée.',
                id_patient=consult.id_patient, matricule=consult.matricule
            )
            db.session.add(notif)
            db.session.commit()
            flash('Consultation enregistrée avec succès.', 'success')
            return redirect(url_for('consultations'))
        except Exception as e:
            db.session.rollback()
            flash(f'Erreur: {str(e)}', 'danger')
    return render_template('nouvelle_consultation.html', patients=patients, medecins=medecins, medicaments=medicaments)

# ─────────────────────────────────────────
# URGENCES
# ─────────────────────────────────────────

@app.route('/urgences')
@login_required
@role_required('admin', 'receptionniste', 'medecin')
def urgences():
    if current_user.role == 'medecin':
        med = current_user.medecin
        urg = Urgence.query.filter_by(id_services=med.id_services).order_by(Urgence.date_arrivee.desc()).all()
    else:
        urg = Urgence.query.order_by(Urgence.date_arrivee.desc()).all()
    patients = Patient.query.all()
    services = Services.query.all()
    return render_template('urgences.html', urgences=urg, patients=patients, services=services)

@app.route('/urgences/nouvelle', methods=['POST'])
@login_required
@role_required('admin', 'receptionniste')
def nouvelle_urgence():
    try:
        urg = Urgence(
            niveau=request.form.get('niveau', 'urgent'),
            statut='en_attente',
            id_patient=request.form.get('id_patient'),
            id_services=request.form.get('id_services')
        )
        db.session.add(urg)
        db.session.flush()
        notif = Notification(
            type='urgence', objet=f'URGENCE - Niveau {urg.niveau.upper()}',
            contenu=f'Urgence enregistrée le {datetime.now().strftime("%d/%m/%Y à %H:%M")}.',
            id_patient=urg.id_patient
        )
        db.session.add(notif)
        db.session.commit()
        flash('Urgence enregistrée.', 'warning')
    except Exception as e:
        db.session.rollback()
        flash(f'Erreur: {str(e)}', 'danger')
    return redirect(url_for('urgences'))

# ─────────────────────────────────────────
# PHARMACIE
# ─────────────────────────────────────────

@app.route('/pharmacie')
@login_required
@role_required('admin', 'pharmacien', 'medecin')
def pharmacie():
    if current_user.role == 'medecin':
        medicaments = Medicament.query.all()
        return render_template('pharmacie.html', medicaments=medicaments, readonly=True)
    medicaments = Medicament.query.all()
    alertes = AlerteStock.query.filter_by(statut='active').order_by(AlerteStock.date.desc()).all()
    stocks = Stock.query.all()
    return render_template('pharmacie.html', medicaments=medicaments, alertes=alertes, stocks=stocks, readonly=False)

@app.route('/pharmacie/medicament/nouveau', methods=['POST'])
@login_required
@role_required('admin', 'pharmacien')
def nouveau_medicament():
    try:
        stock = Stock(quantite=int(request.form.get('quantite', 0)), statut='normal')
        db.session.add(stock)
        db.session.flush()
        med = Medicament(
            libelle=request.form['libelle'], prix=float(request.form.get('prix', 0)),
            dosage=request.form.get('dosage'), contre_indication=request.form.get('contre_indication'),
            notice=request.form.get('notice'), type=request.form.get('type'),
            id_stock=stock.id_stock
        )
        db.session.add(med)
        if stock.quantite < 10:
            alerte = AlerteStock(
                type_alerte='stock_faible', message=f'Stock faible pour {med.libelle}',
                quantite_actuel=stock.quantite, id_stock=stock.id_stock
            )
            db.session.add(alerte)
            stock.statut = 'faible'
        db.session.commit()
        flash('Médicament ajouté.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Erreur: {str(e)}', 'danger')
    return redirect(url_for('pharmacie'))

# ─────────────────────────────────────────
# FACTURATION
# ─────────────────────────────────────────

@app.route('/facturation')
@login_required
@role_required('admin', 'receptionniste')
def facturation():
    factures = Facture.query.order_by(Facture.date.desc()).all()
    return render_template('facturation.html', factures=factures)

@app.route('/facturation/<int:num>/payer', methods=['POST'])
@login_required
@role_required('admin', 'receptionniste')
def payer_facture(num):
    try:
        facture = Facture.query.get_or_404(num)
        paiement = Paiement(
            montant=float(request.form.get('montant', facture.montant)),
            mode_paiement=request.form.get('mode', 'espèces'),
            statut='validé',
            num_facture=facture.num_facture,
            id_patient=facture.consultation.id_patient
        )
        facture.statut = 'payée'
        db.session.add(paiement)
        db.session.commit()
        flash('Paiement enregistré.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Erreur: {str(e)}', 'danger')
    return redirect(url_for('facturation'))

# ─────────────────────────────────────────
# MÉDECINS (admin only)
# ─────────────────────────────────────────

@app.route('/medecins')
@login_required
@role_required('admin', 'receptionniste')
def medecins():
    meds = Medecin.query.all()
    return render_template('medecins.html', medecins=meds)

@app.route('/medecins/nouveau', methods=['GET', 'POST'])
@login_required
@role_required('admin')
def nouveau_medecin():
    services = Services.query.all()
    if request.method == 'POST':
        try:
            user = Utilisateur(username=request.form['username'], role='medecin')
            user.set_password(request.form['password'])
            db.session.add(user)
            db.session.flush()
            med = Medecin(
                nom=request.form['nom'], prenom=request.form['prenom'],
                telephone=request.form.get('telephone'), specialite=request.form.get('specialite'),
                email=request.form.get('email'), id_services=request.form.get('id_services') or None,
                utilisateur_id=user.id
            )
            db.session.add(med)
            db.session.commit()
            flash('Médecin créé avec succès.', 'success')
            return redirect(url_for('medecins'))
        except Exception as e:
            db.session.rollback()
            flash(f'Erreur: {str(e)}', 'danger')
    return render_template('nouveau_medecin.html', services=services)

# ─────────────────────────────────────────
# SERVICES
# ─────────────────────────────────────────

@app.route('/services')
@login_required
@role_required('admin', 'receptionniste')
def services():
    svcs = Services.query.all()
    centres = Centre.query.all()
    return render_template('services.html', services=svcs, centres=centres)

@app.route('/services/nouveau', methods=['POST'])
@login_required
@role_required('admin')
def nouveau_service():
    try:
        svc = Services(
            libelle=request.form['libelle'],
            description=request.form.get('description'),
            id_centre=request.form.get('id_centre') or None
        )
        db.session.add(svc)
        db.session.commit()
        flash('Service ajouté.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Erreur: {str(e)}', 'danger')
    return redirect(url_for('services'))

# ─────────────────────────────────────────
# API NOTIFICATIONS (pour JS polling)
# ─────────────────────────────────────────

@app.route('/api/notifications')
@login_required
def api_notifications():
    query = Notification.query.filter_by(statut='non_lu')
    if current_user.role == 'medecin' and current_user.medecin:
        query = query.filter_by(matricule=current_user.medecin.matricule)
    notifs = query.order_by(Notification.date_envoie.desc()).limit(20).all()
    return jsonify([{
        'id': n.id_notification, 'type': n.type, 'objet': n.objet,
        'contenu': n.contenu, 'date': n.date_envoie.strftime('%d/%m/%Y %H:%M')
    } for n in notifs])

@app.route('/api/notifications/<int:id>/lu', methods=['POST'])
@login_required
def marquer_lu(id):
    notif = Notification.query.get_or_404(id)
    notif.statut = 'lu'
    db.session.commit()
    return jsonify({'success': True})

@app.route('/api/urgences/count')
@login_required
def api_urgences_count():
    count = Urgence.query.filter_by(statut='en_attente').count()
    return jsonify({'count': count})

# ─────────────────────────────────────────
# ADMIN: Gestion utilisateurs
# ─────────────────────────────────────────

@app.route('/admin/utilisateurs')
@login_required
@role_required('admin')
def admin_utilisateurs():
    users = Utilisateur.query.all()
    return render_template('admin_utilisateurs.html', users=users)

@app.route('/admin/utilisateurs/nouveau', methods=['GET', 'POST'])
@login_required
@role_required('admin')
def nouvel_utilisateur():
    if request.method == 'POST':
        try:
            user = Utilisateur(username=request.form['username'], role=request.form['role'])
            user.set_password(request.form['password'])
            db.session.add(user)
            db.session.flush()
            role = request.form['role']
            if role == 'receptionniste':
                rec = Receptionniste(nom=request.form.get('nom',''), prenom=request.form.get('prenom',''),
                                     telephone=request.form.get('telephone'), email=request.form.get('email'),
                                     utilisateur_id=user.id)
                db.session.add(rec)
            elif role == 'pharmacien':
                ph = Pharmacien(nom=request.form.get('nom',''), prenom=request.form.get('prenom',''),
                                telephone=request.form.get('telephone'), email=request.form.get('email'),
                                utilisateur_id=user.id)
                db.session.add(ph)
            db.session.commit()
            flash('Utilisateur créé.', 'success')
            return redirect(url_for('admin_utilisateurs'))
        except Exception as e:
            db.session.rollback()
            flash(f'Erreur: {str(e)}', 'danger')
    return render_template('nouvel_utilisateur.html')

# ─────────────────────────────────────────
# INIT DB + SEED
# ─────────────────────────────────────────

def seed_data():
    if Utilisateur.query.first():
        return
    # Admin
    admin = Utilisateur(username='admin', role='admin')
    admin.set_password('admin123')
    db.session.add(admin)
    # Centre
    centre = Centre(designation='Centre de Santé Le Tropical', adresse='Thiès, Sénégal', telephone='+221 33 000 0000')
    db.session.add(centre)
    db.session.flush()
    # Services
    svcs = [
        Services(libelle='Pédiatrie', description='Soins enfants', id_centre=centre.id_centre),
        Services(libelle='Gynécologie', description='Santé féminine', id_centre=centre.id_centre),
        Services(libelle='Médecine Générale', description='Consultations générales', id_centre=centre.id_centre),
        Services(libelle='Urgences', description='Prise en charge urgente', id_centre=centre.id_centre),
    ]
    for s in svcs: db.session.add(s)
    db.session.flush()
    # Médecin
    u_med = Utilisateur(username='dr_diallo', role='medecin')
    u_med.set_password('medecin123')
    db.session.add(u_med)
    db.session.flush()
    med = Medecin(nom='Diallo', prenom='Amadou', telephone='+221 77 111 1111',
                  specialite='Médecin Généraliste', email='a.diallo@tropical.sn',
                  id_services=svcs[2].id_services, utilisateur_id=u_med.id)
    db.session.add(med)
    # Réceptionniste
    u_rec = Utilisateur(username='receptionniste', role='receptionniste')
    u_rec.set_password('recep123')
    db.session.add(u_rec)
    db.session.flush()
    rec = Receptionniste(nom='Ndiaye', prenom='Fatou', telephone='+221 77 222 2222',
                         email='f.ndiaye@tropical.sn', utilisateur_id=u_rec.id)
    db.session.add(rec)
    # Pharmacien
    u_ph = Utilisateur(username='pharmacien', role='pharmacien')
    u_ph.set_password('pharma123')
    db.session.add(u_ph)
    db.session.flush()
    stock1 = Stock(quantite=50, statut='normal')
    db.session.add(stock1)
    db.session.flush()
    ph = Pharmacien(nom='Sow', prenom='Ibrahima', telephone='+221 77 333 3333',
                    email='i.sow@tropical.sn', id_stock=stock1.id_stock, utilisateur_id=u_ph.id)
    db.session.add(ph)
    # Assurance
    ass = Assurance(nom_assurance='IPM Sénégal', adresse_assurance='Dakar', contrat='Standard')
    db.session.add(ass)
    db.session.flush()
    # Patients
    patients_data = [
        ('Ndiaye', 'Moussa', 'M', '1985-03-15', '+221 77 444 4444'),
        ('Fall', 'Aminata', 'F', '1990-07-22', '+221 77 555 5555'),
        ('Sarr', 'Omar', 'M', '1978-11-10', '+221 77 666 6666'),
    ]
    for nom, prenom, sexe, dob, tel in patients_data:
        p = Patient(nom=nom, prenom=prenom, sexe=sexe,
                    date_naissance=datetime.strptime(dob, '%Y-%m-%d').date(),
                    telephone=tel, adresse='Thiès, Sénégal', id_assurance=ass.id_assurance)
        db.session.add(p)
        db.session.flush()
        d = Dossier(id_patient=p.id_patient)
        db.session.add(d)
    # Médicaments
    db.session.flush()
    meds_data = [
        ('Paracétamol 500mg', 500, '500mg', 'Insuffisance hépatique', 'Analgésique', 'comprimé', 30),
        ('Amoxicilline 250mg', 1200, '250mg', 'Allergie pénicilline', 'Antibiotique', 'gélule', 20),
        ('Ibuprofène 400mg', 800, '400mg', 'Insuffisance rénale', 'Anti-inflammatoire', 'comprimé', 5),
    ]
    for libelle, prix, dosage, ci, notice, typ, qte in meds_data:
        st = Stock(quantite=qte, statut='normal' if qte > 10 else 'faible')
        db.session.add(st)
        db.session.flush()
        m = Medicament(libelle=libelle, prix=prix, dosage=dosage,
                       contre_indication=ci, notice=notice, type=typ, id_stock=st.id_stock)
        db.session.add(m)
        if qte <= 10:
            alerte = AlerteStock(type_alerte='stock_faible', message=f'Stock faible: {libelle}',
                                 quantite_actuel=qte, id_stock=st.id_stock)
            db.session.add(alerte)
    db.session.commit()
    print("✅ Données de démo insérées.")

with app.app_context():
    db.create_all()
    seed_data()

if __name__ == '__main__':
    app.run(debug=False)
